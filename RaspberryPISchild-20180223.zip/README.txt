Please check https://easyeda.com/dillon/Backup_Your_EasyEDA_Project_Locally-JrecamWv5 out to know how to use these files.
